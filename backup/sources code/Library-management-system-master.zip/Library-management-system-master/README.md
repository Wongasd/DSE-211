# Library-management-system
a simple website for library management system on php and mysql

Live demo can be found [here](http://athena.nitc.ac.in/~shah_b160632cs)
